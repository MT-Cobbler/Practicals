//  Section 1

document.getElementById("calculateLength").onclick = function(){
	// Button handler code goes here
}

// Section 2

document.getElementById("startAnimation").onclick = function(){
	// Button handler code goes here
}