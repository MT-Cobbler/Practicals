$(() => {
	$("section .row button:contains('Login')").on("click",  event =>{
		event.preventDefault();
        let email = $("section .row #loginEmail").val();
        let password = $("section .row #loginPass").val();
		let warningSection = $("section .row .row mt-3:contains('Login')");
        $.ajax({
            url: "checkPassword.php",
            type: 'POST',
            data: {email : email, pass: password}
        })
        .then(data =>{
			$("div.row div.col-12:nth-child(1) .card").append(
				$("<div></div>", {
				html: data,
				class: 'alert alert-warning'
				})
				);
			
        });

        });
        $(document).ajaxError((event, request, settings, thrownError) => {
            console.log('Error requesting page ${settings.url}: ${thrownError}');
        })
        $(document).ajaxSend(() =>{
            $("section .row button:contains('Login')").prop("disabled", true);
        });
        $(document).ajaxComplete(() =>{
            $("section .row button:contains('Login')").prop("disabled", false);
        });
	});



	