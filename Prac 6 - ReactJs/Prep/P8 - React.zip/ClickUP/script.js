const synths = [
	{name: "Minimoog", manufacturer: "Moog", released: 1970}, 
	{name: "MS-20", manufacturer: "Korg", released: 1978}, 
	{name: "Juno-106", manufacturer: "Roland", released: 1984}, 
	{name: "Prophet-5", manufacturer: "Sequential Circuits", released: 1978}, 
	{name: "DX-7", manufacturer: "Yamaha", released: 1983}, 
	{name: "Jupiter-8", manufacturer: "Roland", released: 1981}, 
	{name: "Chroma Polaris", manufacturer: "Rhodes", released: 1984}, 
	{name: "Mono/Poly", manufacturer: "Korg", released: 1981}, 
	{name: "SH-101", manufacturer: "Roland", released: 1983}, 
	{name: "Casiotone 101", manufacturer: "Casio", released: 1981}
];